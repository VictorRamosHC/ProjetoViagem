Note of the author
By installing or using this font, you are agree to the Product Usage Agreement:

1. This font is FOR PERSONAL USE ONLY. NO COMMERCIAL USE ALLOWED!
2. You are REQUIRES A LICENSE for PROMOTIONAL or COMMERCIAL USE.
3. LINK TO PURCHASE COMMERSIAL LICENSE:

if you want a commercial license of my fonts, please Visit :

Envato Element :
https://elements.envato.com/user/SlideShoot/fonts?page=1

Creative Market :
https://creativemarket.com/slideshoot?page=1&category=3

Youworkforthem :
https://www.youworkforthem.com/designer/1757/slide-font

If you need a custom license please contact us at
slideshootfont@gmail.com

Thank you.